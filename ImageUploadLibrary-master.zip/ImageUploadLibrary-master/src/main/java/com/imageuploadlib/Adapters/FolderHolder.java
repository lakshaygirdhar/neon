package com.imageuploadlib.Adapters;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Lakshay on 27-02-2015.
 */
public class FolderHolder {

    ImageView imageView;
    TextView countFiles;
    TextView FolderName;
}
