package com.imageuploadlib.Interfaces;


/**
 * Created by Lakshay on 09-03-2015.
 */
public interface UpdateSelection {
    public void updateSelected(String imagePath, Boolean selected);
}